import 'package:flutter/material.dart';

class Pavlova extends StatelessWidget {
  const Pavlova({super.key, required String title});
  TextStyle txtdesign() {
    return const TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 18,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.blue,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'Sumalan_Activity 1',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const SizedBox(height: 20),
          buildNewRow(),
          const SizedBox(height: 20),
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.favorite,
                color: Colors.pink,
                size: 24.0,
              ),
              Icon(
                Icons.audiotrack,
                color: Colors.green,
                size: 30.0,
              ),
              Icon(
                Icons.beach_access,
                color: Colors.blue,
                size: 36.0,
              ),
            ],
          ),
          const SizedBox(height: 20),
          buildStar(2, 90),
          const SizedBox(height: 20),
          buildRowTabs(),
        ],
      ),
    );
  }

  Widget buildNewRow() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 10),
        Image.asset('assets/pavlova.png'),
        const SizedBox(height: 10),
        const Text(
          'Strawberry Pavlova',
          textAlign: TextAlign.left,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 32,
          ),
        ),
        const Text(
          'Pavlova is a meringue-based dessert named after the Russian ballerina Anna Pavlova. Pavlova features a crisp crust and soft, light inside, topped with fruit and whipped cream.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.normal,
            fontSize: 16,
          ),
        ),
      ],
    );
  }

  Row buildStar(int rating, int reviews) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (int i = 1; i <= rating; i++)
          const Icon(
            Icons.star,
            color: Colors.yellow,
            size: 50,
          ),
        for (int i = 1; i <= (5 - rating); i++)
          const Icon(
            Icons.star_border,
            size: 50,
          ),
        const SizedBox(width: 20),
        Text(
          '$reviews Reviews',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ],
    );
  }

  Row buildRowTabs() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        buildIconTab(Icons.kitchen, 'PREP', '25 mins'),
        const SizedBox(width: 20),
        buildIconTab(Icons.timer, 'COOK', '1 hr'),
        const SizedBox(width: 20),
        buildIconTab(Icons.restaurant, 'FEEDS', '4-6 Hrs'),
      ],
    );
  }

  Column buildIconTab(IconData iconval, String title, String time) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(iconval, color: Colors.yellow),
        const SizedBox(height: 10),
        Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Text(
          time,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
